/*
 * Pas.cpp
 *
 *  Created on: 30 okt. 2018
 *      Author: Jochem
 */

#include "Pas.h"

Pas::Pas() {
	// TODO Auto-generated constructor stub

}

Pas::~Pas() {
	// TODO Auto-generated destructor stub
}

int Pas::getPasnummer() const {
	return pasnummer;
}
