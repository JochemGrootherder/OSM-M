/*
 * Paal.cpp
 *
 *  Created on: 30 okt. 2018
 *      Author: Jochem
 */

#include "Paal.h"

Paal::Paal() {
	// TODO Auto-generated constructor stub

}

Paal::~Paal() {
	// TODO Auto-generated destructor stub
}

void Paal::scanPas() {
}

void Paal::checkAuto() {
}
