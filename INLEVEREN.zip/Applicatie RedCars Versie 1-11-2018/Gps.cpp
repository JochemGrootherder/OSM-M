/*
 * Gps.cpp
 *
 *  Created on: 30 okt. 2018
 *      Author: Jochem
 */

#include "Gps.h"

Gps::Gps() {
	// TODO Auto-generated constructor stub

}

Gps::~Gps() {
	// TODO Auto-generated destructor stub
}

void Gps::scanPas() {
}

void Gps::getCoordinaten() {
}
